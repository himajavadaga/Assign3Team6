function validateContactForm(){
	if(document.getElementById("name").value==""){
		alert("Please Enter Username");
		}
	else if(!validateemail()){		
		alert("Please Enter Valid Email Address");
		}
	else if(document.getElementById("phno").value==""){
		alert("Please Enter your Phone Number");			
		}
	else{
	$("#myModal").modal();
		}
}

function validateemail(){
	var x = document.getElementById("email").value;
    var atpos = x.indexOf("@");
    var dotpos = x.lastIndexOf(".");
    if (atpos<1 || dotpos<atpos+2 || dotpos+2>=x.length) {        
        return false;
    }
	else{
		return true;
	}
}

function storeformvalues(){
	var name
	
}





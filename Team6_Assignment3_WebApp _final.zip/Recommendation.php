<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Recommendation</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-casual.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="brand">Recommendation</div>
    <div class="address-bar"></div>
	<div align="right">
	<button onclick="location.href='login.php'" type="button" class="btn btn-default btn-sm">
          <span align="right" class="glyphicon glyphicon-log-out"></span> Sign-Out
	</button>
	</div>
    <!-- Navigation -->
    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- navbar-brand is hidden on larger screens, but visible when the menu is collapsed -->
                <a class="navbar-brand" href="index.html">Recommendation</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">The Dataset</a>
                    </li>                    
					<li>
					<a class="dropdown-toggle" data-toggle="dropdown" href="groceries.html">Algorithm Visualizations <span class="glyphicon glyphicon-chevron-down"></a>
					<ul class="dropdown-menu">
						<li><a href="Recommendation.php">Recommendation</a></li>
						<li><a href="Classification.php">Classification</a></li>														<li><a href="Prediction.php">Prediction</a></li>
					</ul>
					</li>
					<li>
                        <a href="contact.php">Contact Us</a>
                    </li>                    	
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <div class="container">

        <div class="row">
            <div class="box"> 
			
			<?php	
				
				//echo "My first PHP script!";
				/*if(isset($_POST['name'])) {	
				$custid = $_POST['name'];
				
				$pyscript = 'C:\\wamp64\\www\\ADSTeam6Assign3\\python\\recwebservice.py';
				$python = 'C:\\Users\\bryce\\AppData\\Local\\Programs\\Python\\Python35-32\\python.exe';
				$cmd = "$python $pyscript";
				//echo $cmd;
				
				exec("$cmd $custid", $output);
				echo $output[0];
				
				
				
				}
				//echo $output[1];
				//echo $output[2];
				//echo $output[3];
				//echo $output[4];
				//echo $output[5];											
				//echo $output[6];									
				*/
			?>
						
			<table class="table">
				<thead>
					<tr>
						<th><label>Please enter the Customer ID</label></th>
						<th></th>
						<th>Recommended Products</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>
						 <select class="form-control" id="custid">
								<option>14702</option>
								<option>17962</option>
								<option>18150</option>
								<option>15296</option>
								<option>16759</option>
								<option>13819</option>
								<option>14047</option>
							</select>
						</td>
						<td></td>
						<td><label>Product No. 1</label>&nbsp;&nbsp;<input id="prod1" type="text" disabled></td>
					</tr>
					<tr>
						<td><button type="button" class="btn btn-primary" >Recommend</button></td>
						<td></td>
						<td><label>Product No. 2</label>&nbsp;&nbsp;<input id="prod2" type="text" disabled></td>
					</tr>
					<tr>
						<td><br></td>
						<td></td>
						<td><label>Product No. 3</label>&nbsp;&nbsp;<input id="prod3" type="text" disabled></td>
					</tr>
					<tr>
						<td><br></td>
						<td></td>
						<td><label>Product No. 4</label>&nbsp;&nbsp;<input id="prod4" type="text" disabled></td>
					</tr>
					<tr>
						<td><br></td>
						<td></td>
						<td><label>Product No. 5</label>&nbsp;&nbsp;<input id="prod5" type="text" disabled></td>
					</tr>					
				</tbody>
			</table>			
			</div>			
        </div>		              
    </div>
    <!-- /.container -->

    

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<script>			
	
	var ritems = 0;
	
	//$(document).ready(function(){
    $('button').click(function(){
		var custid = $("#custid").val();		
        $.post("webservicecall.php",
        {
          name: custid
        },
        function(data, status){
            recodata(data)
        });
    });
//});

		function recodata(data){			
			var data1 = JSON.stringify(data);			
			var data1_array = data1.split(',');
			//console.log(data1);	
		for(var i = 0; i < data1.length; i++) {   			
			//alert(data1_array[i]);
			document.getElementById('prod1').value = data1_array[1];
			document.getElementById('prod2').value = data1_array[2];
			document.getElementById('prod3').value = data1_array[3];
			document.getElementById('prod4').value = data1_array[4];
			document.getElementById('prod5').value = data1_array[5];
			}			
		}
		 
		 
		 
	</script>
</body>
</html>

<?php			

//echo $_POST['name'];
$custid = $_POST['name'];


				$pyscript = 'D:\\home\\site\\wwwroot\\ADSTeam6Assign3\\python\\recwebservice.py';
				$python = 'D:\\Python34\\python.exe';
				$cmd = "$python $pyscript";
				//echo $cmd;

				exec("$cmd $custid", $output);
				//echo $output[0];
				$comma = ',';
				echo $output[1].$comma.$output[2].$comma.$output[3].$comma.$output[4].$comma.$output[5].$comma.$output[6].$comma.$output[6];
				
?>
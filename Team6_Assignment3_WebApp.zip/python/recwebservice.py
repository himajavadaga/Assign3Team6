import urllib.request
# If you are using Python 3+, import urllib instead of urllib2

import json
import sys


value = sys.argv[1]

data =  {
        "Inputs": {
                "input1":
                {
                    "ColumnNames": ["CustomerID"],
                    "Values": [ [ value ], ]
                },        },
            "GlobalParameters": {
}
    }

body = str.encode(json.dumps(data))
url = 'https://ussouthcentral.services.azureml.net/workspaces/421d1d461c7d416aa6c9555030cf3e2f/services/7f4971ec0e6c4d2aa99adc0795c8b0a6/execute?api-version=2.0&details=true'
api_key = 'ULumkh1ETQT51IC0fYsZirjF4lPpIoxOK+KlVaTVCusgdzkAdv0KVgdiedh3qHNtI5LuHqvdP+kG40E26Awmeg==' # Replace this with the API key for the web service
headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ api_key)}

req = urllib.request.Request(url, body, headers) 

response = urllib.request.urlopen(req)
result = response.read().decode('utf-8')
#result1 = str(result)
#result2 = type(result1) is str
#result3 = json.loads(result1)
#result4 = type(result3) is json
json_obj = json.loads(result)
print(json_obj)
print(json_obj['Results']['output1']['value']['Values'][0][0])
print(json_obj['Results']['output1']['value']['Values'][0][1])
print(json_obj['Results']['output1']['value']['Values'][0][2])
print(json_obj['Results']['output1']['value']['Values'][0][3])
print(json_obj['Results']['output1']['value']['Values'][0][4])
print(json_obj['Results']['output1']['value']['Values'][0][5])
import urllib.request
# If you are using Python 3+, import urllib instead of urllib2

import json 
import sys

year = sys.argv[1]
month = sys.argv[2]
country = sys.argv[3]
pid = sys.argv[4]
pname = sys.argv[5]

data =  {

        "Inputs": {

                "input1":
                {
                    "ColumnNames": ["Year", "Month", "Product_Id", "Country", "Product_Name"],
                    "Values": [[year, month, pid, country, pname],]
                },        },
            "GlobalParameters": {
}
    }

body = str.encode(json.dumps(data))

url = 'https://ussouthcentral.services.azureml.net/workspaces/421d1d461c7d416aa6c9555030cf3e2f/services/fc0c1eacacaa43828f129dcad8910892/execute?api-version=2.0&details=true'
api_key = '5tUmfw74sJf1z16vjrCQRUAeUaItvXE7MhM2/T0irxN9na8DCiJsRmnCBPEA5yOByg/fm04rI6v2uu8N/Skf/w==' # Replace this with the API key for the web service
headers = {'Content-Type':'application/json', 'Authorization':('Bearer '+ api_key)}

req = urllib.request.Request(url, body, headers)

response = urllib.request.urlopen(req)
result = response.read().decode('utf-8')

# If you are using Python 3+, replace urllib2 with urllib.request in the above code:
# req = urllib.request.Request(url, body, headers) 
# response = urllib.request.urlopen(req)
#result = response.read()
    
json_obj = json.loads(result)
print(json_obj)
print(json_obj['Results']['output1']['value']['Values'][0][0])
print(json_obj['Results']['output1']['value']['Values'][0][1])
print(json_obj['Results']['output1']['value']['Values'][0][2])
print(json_obj['Results']['output1']['value']['Values'][0][3])
print(json_obj['Results']['output1']['value']['Values'][0][4])
print(json_obj['Results']['output1']['value']['Values'][0][5])	
print(json_obj['Results']['output1']['value']['Values'][0][6])
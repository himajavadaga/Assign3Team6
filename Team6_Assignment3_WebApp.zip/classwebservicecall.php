<?php			

//echo $_POST['name'];
$year = $_POST['year1'];
$month = $_POST['month1'];
$country = $_POST['country1'];
$pid = $_POST['pid1'];
$pname = $_POST['pname1'];


				$pyscript = 'D:\\home\\site\\wwwroot\\ADSTeam6Assign3\\python\\classwebservice.py';
				$python = 'D:\\Python34\\python.exe';
				
				//**there has to be a space after $pyscript**
				$cmd = "$python $pyscript " .$year." ".$month." ".$country." ".$pid." ".$pname;
				//echo $cmd;
				
				exec("$cmd", $output);
				//echo $output[0];
				$comma = ',';
				echo $output[1].$comma.$output[2].$comma.$output[3].$comma.$output[4].$comma.$output[5].$comma.$output[6].$comma.$output[7].$comma.$output[7];
				
?>
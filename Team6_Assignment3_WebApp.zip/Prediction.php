<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Prediction</title>

    <!-- Bootstrap Core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">

    <!-- Custom CSS -->
    <link href="css/business-casual.css" rel="stylesheet">

    <!-- Fonts -->
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300italic,400italic,600italic,700italic,800italic,400,300,600,700,800" rel="stylesheet" type="text/css">
    <link href="http://fonts.googleapis.com/css?family=Josefin+Slab:100,300,400,600,700,100italic,300italic,400italic,600italic,700italic" rel="stylesheet" type="text/css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

</head>

<body>

    <div class="brand">Prediction</div>
    <div class="address-bar"></div>
	<div align="right">
	<button onclick="location.href='login.php'" type="button" class="btn btn-default btn-sm">
          <span align="right" class="glyphicon glyphicon-log-out"></span> Sign-Out
	</button>
	</div>
    <!-- Navigation -->
    <nav class="navbar navbar-default" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <!-- navbar-brand is hidden on larger screens, but visible when the menu is collapsed -->
                <a class="navbar-brand" href="index.html">Prediction</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">The Dataset</a>
                    </li>                    
					<li>
					<a class="dropdown-toggle" data-toggle="dropdown" href="groceries.html">Algorithm Visualizations <span class="glyphicon glyphicon-chevron-down"></a>
					<ul class="dropdown-menu">
						<li><a href="Recommendation.php">Recommendation</a></li>
						<li><a href="Classification.php">Classification</a></li>											
						<li><a href="Prediction.php">Prediction</a></li>
					</ul>
					</li>
					<li>
                        <a href="contact.php">Contact Us</a>
                    </li>                    	
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>

    <div class="container">

        <div class="row">
            <div class="box"> 
			
			<?php	
				/*
				echo "My first PHP script!";
					
				$year = '2010';
				$month = 'January';
				$country = 'United_Kingdom';
				$pid = '22138';
				$pname = 'BAKING_SET_9_PIECE_RETROSPOT';					
	
					
				$pyscript = 'C:\\wamp64\\www\\ADSTeam6Assign3\\python\\predwebservice.py';
				$python = 'C:\\Users\\bryce\\AppData\\Local\\Programs\\Python\\Python35-32\\python.exe';
				$cmd = "$python $pyscript " .$year." ".$month." ".$country." ".$pid." ".$pname;
				echo $cmd;

				exec("$cmd" , $output);
				
				echo $output[0];
				$comma = ',';											
				
				echo $output[1];
				echo $output[2];
				echo $output[3];
				echo $output[4];
				echo $output[5];											
				echo $output[6];									
				*/
			?>
						
			<table class="table" border="0" style="table-layout:fixed;" width="100%">
				<thead>
					<tr>
						<th width="30%"><label>Please enter the following details &nbsp; &nbsp; &nbsp; &nbsp;</label></th>
						<th width="30%"><label>Output</label><th/>
						<th></th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td>						
							Year: <select class="form-control" id="year">
								<option>2010</option>
								<option>2011</option>
								<option>2012</option>
								<option>2013</option>
								<option>2014</option>
								<option>2015</option>
								<option>2016</option>
								<option>2017</option>
								<option>2018</option>
								<option>2019</option>
								<option>2020</option>								
							</select>							
						<br>
						Month: <select class="form-control" id="month">
								<option>January</option>
								<option>February</option>
								<option>March</option>
								<option>April</option>
								<option>May</option>
								<option>June</option>
								<option>July</option>
								<option>August</option>
								<option>September</option>
								<option>October</option>
								<option>November</option>
								<option>December</option>
							</select>							
						<br>
						Country: <select class="form-control" id="country">
								<option>United_Kingdom</option>
								<option>France</option>
								<option>Australia</option>
								<option>Netherlands</option>
								<option>Germany</option>
								<option>Norway</option>
								<option>EIRE</option>
								<option>Switzerland</option>
								<option>Spain</option>
								<option>Poland</option>
								<option>Portugal</option>
								<option>Italy</option>								
								<option>Belgium</option>
								<option>Lithuania</option>
								<option>Japan</option>
								<option>Iceland</option>
								<option>Channel_Islands</option>
								<option>Denmark</option>
								<option>Cyprus</option>
								<option>Sweden</option>
								<option>Austria</option>
								<option>Israel</option>
								<option>Finland</option>
								<option>Bahrain</option>								
								<option>Greece</option>
								<option>Hong_Kong</option>
								<option>Singapore</option>
								<option>Lebanon</option>
								<option>United_Arab_Emirates</option>
								<option>Saudi_Arabia</option>
								<option>Czech_Republic</option>
								<option>Canada</option>
								<option>Unspecified</option>
								<option>Brazil</option>
								<option>USA</option>
								<option>European_Community</option>
								<option>Malta</option>
								<option>RSA</option>
							</select>
						<br>
						Product ID: <select class="form-control" id="pid">
								<option>22138</option>
								<option>85123A</option>
								<option>581587</option>
								<option>37479P</option>
								<option>23110</option>
								<option>22328</option>
								<option>23206</option>								
							</select>
						<br>
						Product Name: <select class="form-control" id="pname">
								<option>BAKING_SET_9_PIECE_RETROSPOT</option>
								<option>WHITE_HANGING_HEART_T-LIGHT_HOLDER</option>
								<option>ALARM_CLOCK_BAKELIKE_IVORY</option>
								<option>CUBIC_MUG_FLOCK_PINK_ON_BROWN</option>
								<option>PARISIENNE_KEY_CABINET</option>
								<option>ROUND_SNACK_BOXES_SET_OF_4_FRUITS</option>
								<option>LUNCH_BAG_APPLE_DESIGN</option>								
							</select>
						<br><br>
						<button type="button" class="btn btn-primary">Predict</button>
						</td>
						<td style="word-wrap=break-word;">Sales Prediction:						
						<input class="form-control" id="sale" type="text" disabled>
						</td>
						<td> 
						</td>
					</tr>					
				</tbody>
			</table>			
			</div>			
        </div>		              
    </div>
    <!-- /.container -->

    

    <!-- jQuery -->
    <script src="js/jquery.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="js/bootstrap.min.js"></script>
	
	<script>			
	
	var ritems = 0;
	
	//$(document).ready(function(){
    $('button').click(function(){
		
		var year = $("#year").val();
		var mth = $("#month").val();
		var country = $("#country").val();
		var pid = $("#pid").val();
		var pname = $("#pname").val();
		
        $.post("predwebservicecall.php",
        {
          year1: year,
		  month1: mth,
		  country1: country,
		  pid1: pid,
		  pname1: pname
        },
        function(data, status){
            recodata(data)
        });
    });
//});

		function recodata(data){			
			var data1 = JSON.stringify(data);			
			var data1_array = data1.split(',');
			console.log(data1);	
		for(var i = 0; i < data1.length; i++) {   			
			//alert(data1_array[i]);
			document.getElementById('sale').value = data1_array[5];			
			
			}			
		}
		 
		 
		 
	</script>
</body>
</html>